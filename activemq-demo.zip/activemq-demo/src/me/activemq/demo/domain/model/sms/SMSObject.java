package me.activemq.demo.domain.model.sms;

/**
 * Created by _liwenhe on 2015/2/28.
 */
public class SMSObject {
}
